import xml.etree.ElementTree as ET
import pygame
import pyscroll
import pytmx

pygame.init()
y = ''
maps = ['salle1.tmx', 'salle1.tmx']
nb = 1
layer_finale = []
for map in maps:
    layer_data = ''
    layer_data2 = []
    # Charger le contenu du fichier TMX (remplacez 'your_map_file.tmx' par le chemin réel du fichier)
    tree = ET.parse(map)
    root = tree.getroot()

    # Accéder à la première couche <layer> et extraire les données <data> à l'intérieur
    for layer in root.findall('layer'):
        layer_data += layer.find('data').text.strip()
    layer_data = layer_data.split(',')
    # Ici, 'data' contient le contenu textuel de la balise <data>, c'est-à-dire les indices des tuiles
        
    for i in range(0, 400, 20):
        layer_data2.append(layer_data[i:(i+20)])
    
    nb2 = 1
    for i in layer_data2:
        layer_finale.insert(nb*nb2-1 , i)
        nb2 += 1
    nb+=1
    
for row in layer_finale:
    z = ','.join(row)
    y += z
    y += ','
y = y[:len(y)-1] 

screen = pygame.display.set_mode((640,320))
pygame.display.set_caption("Dungeon Example")
# Créer l'élément racine <map> avec ses attributs
map_elem = ET.Element("map", version="1.10", tiledversion="1.10.2",
                    orientation="orthogonal", renderorder="right-down", width="20", height="20", tilewidth="16",
                    tileheight="16", infinite="0", nextlayerid="2", nextobjectid="1")

# Créer un tileset
tileset = ET.SubElement(map_elem, "tileset", firstgid="1", source="Tiles.tsx")

# Sauvegarder l'arbre XML dans un fichier
tree = ET.ElementTree(map_elem)
tree.write("new_map.tmx", xml_declaration=True, encoding='UTF-8')

# Créer un élément <layer>
layer = ET.SubElement(map_elem, "layer", id="1", name="Layer 1", width=str(40), height="20")

# Créer un élément <data> avec un encodage CSV
data = ET.SubElement(layer, "data", encoding="csv")

# Insérer les données de tuiles (vous devriez remplacer cela par vos propres données)
data.text = y

# Sauvegarder les modifications dans le fichier
tree.write("new_map.tmx", xml_declaration=True, encoding='UTF-8')


def load_map(filename):
    tmx_data = pytmx.util_pygame.load_pygame(filename)
    map_data = pyscroll.data.TiledMapData(tmx_data)
    map_layer = pyscroll.orthographic.BufferedRenderer(map_data, (1200, 400))
    group = pyscroll.PyscrollGroup(map_layer=map_layer, default_layer=0)
    return group

groupe = load_map('new_map.tmx')

running = True
while running:

    screen.fill((0, 0, 0))
    groupe.draw(screen)
    pygame.display.flip()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

pygame.quit()