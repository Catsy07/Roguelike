import xml.etree.ElementTree as ET
import pygame
import pyscroll
import pytmx

pygame.init()
y = ''
maps = ['salle1.tmx', 'salle2.tmx']
nb = 0
for map in maps:
    layer_data = ''
    layer_data2 = []
    nb+=1
    # Charger le contenu du fichier TMX (remplacez 'your_map_file.tmx' par le chemin réel du fichier)
    tree = ET.parse(map)
    root = tree.getroot()

    # Accéder à la première couche <layer> et extraire les données <data> à l'intérieur
    for layer in root.findall('layer'):
        layer_data += layer.find('data').text.strip()
    layer_data = layer_data.split(',')
    # Ici, 'data' contient le contenu textuel de la balise <data>, c'est-à-dire les indices des tuiles
        
    for i in range(0, 400, 20):
        layer_data2.append(layer_data[i:(i+20)])
    
    for row in layer_data2:
        z = ','.join(row)
        y += z
        y += ','

y = y[:len(y)-1] 
print(y)
print(type(y))