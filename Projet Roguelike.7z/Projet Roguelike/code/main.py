import pygame
import os

from game import Game
if __name__ == '__main__':
    pygame.init()
    game = Game()
    game.go()

